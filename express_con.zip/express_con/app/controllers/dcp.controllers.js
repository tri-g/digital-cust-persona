var mysql      = require('mysql2');
var connection = mysql.createConnection({
host     : 'localhost', 
  user     : 'root', 
  password : 'root', 
  database : 'dcp'
  });
  connection.connect(function(err) {
  if (err) throw err
  console.log('You are now connected...')
})
  
exports.listall = (req, res) => {
connection.query('select * from demographics_with_product_id', function (error, results, fields) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
};

exports.listbyid = (req, res) => {
 console.log(req);
   connection.query('select * from demographics_with_product_id where client_id=?', [req.params.client_id], function (error, results, fields) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
};
