import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'app-demographics',
  templateUrl: './demographics.component.html',
  styleUrls: ['./demographics.component.css']
})

export class DemographicsComponent implements OnInit {
  
  constructor(private router: Router,
  	private route: ActivatedRoute) {}
    
  

  ngOnInit() {
  }
onsubmit()
{
	this.router.navigate(['/pie']);
}
}
