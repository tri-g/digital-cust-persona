import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { PersonalTrendsComponent } from './personal-trends/personal-trends.component';
import { PersonalComponent } from './personal/personal.component';
import { RiskComponent } from './risk/risk.component';
import { ProductComponent } from './product/product.component';
import { NnComponent } from './nn/nn.component';

const routes: Routes = [
{ path: '', redirectTo: 'home', pathMatch: 'full'},
{ path: 'home', component: HomeComponent},
{ path: 'personal', component: PersonalTrendsComponent},
{ path: 'personalinfo', component: PersonalComponent},
{ path: 'risk', component: RiskComponent},
{ path: 'product', component: ProductComponent},
{ path: 'neighbours', component: NnComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
