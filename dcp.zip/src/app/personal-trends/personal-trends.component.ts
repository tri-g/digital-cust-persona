import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'app-personal-trends',
  templateUrl: './personal-trends.component.html',
  styleUrls: ['./personal-trends.component.css']
})
export class PersonalTrendsComponent implements OnInit {

constructor( private router: Router,
  	private route: ActivatedRoute) { }

  ngOnInit() {
  }
  
onSubmit1() {
  	this.router.navigate(['/personalinfo']);
  }
  onSubmit2() {
  	this.router.navigate(['/risk']);
  }
  onSubmit3() {
  	this.router.navigate(['/product']);
  }
  onSubmit4() {
  	this.router.navigate(['/neighbours']);
  }
}
