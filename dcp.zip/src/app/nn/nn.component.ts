import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nn',
  templateUrl: './nn.component.html',
  styleUrls: ['./nn.component.css']
})
export class NnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
