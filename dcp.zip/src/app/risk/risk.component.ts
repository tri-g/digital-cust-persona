import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-risk',
  templateUrl: './risk.component.html',
  styleUrls: ['./risk.component.css']
})
export class RiskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
myFunction1() {
  document.getElementById("demo1").innerHTML = "***data***";
}
myFunction2() {
  document.getElementById("demo2").innerHTML = "***data***";
}
myFunction3() {
  document.getElementById("demo3").innerHTML = "***data***";
}
myFunction4() {
  document.getElementById("demo4").innerHTML = "***data***";
}
myFunction5() {
  document.getElementById("demo5").innerHTML = "***data***";
}
myFunction6() {
  document.getElementById("demo6").innerHTML = "***data***";
}
}
